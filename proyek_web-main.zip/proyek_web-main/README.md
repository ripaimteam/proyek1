## Identitas Kelompok RIP-AIM

- Nama : Faiq Maulana
- NIM  : 1931710098

- Nama : Muhammad Ivan Fadhilah
- NIM  : 1931710120


## Fitur
- Visit Counter
- Text Berjalan
- Video Youtube
- Google Maps
- Live Chat
- Share to Sosmed
- Chat to WhatsApp


## Isi Project

- LoginPage    (/login)
- RegisterPage (/register)
- HomePage     (/home)
- AboutPage    (/about)
- PackagePage (/package)
- ContactPage  (/contact)
